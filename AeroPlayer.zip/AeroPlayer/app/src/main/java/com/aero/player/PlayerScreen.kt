package com.aero.player

import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.media.AudioManager
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Flip
import androidx.compose.material.icons.rounded.Headset
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.NightsStay
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

// ───────────────────────── Video effects (night / HD) ─────────────────────────

private fun fxPaint(night: Boolean, hd: Boolean): Paint? {
    if (!night && !hd) return null
    val cm = ColorMatrix()
    if (hd) {
        cm.setSaturation(1.2f)
        val c = 1.1f
        val t = 128f * (1f - c)
        cm.postConcat(
            ColorMatrix(
                floatArrayOf(
                    c, 0f, 0f, 0f, t,
                    0f, c, 0f, 0f, t,
                    0f, 0f, c, 0f, t,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }
    if (night) {
        val n = ColorMatrix()
        n.setScale(.78f, .72f, .60f, 1f)
        cm.postConcat(n)
    }
    return Paint().apply { colorFilter = ColorMatrixColorFilter(cm) }
}

private fun spLabel(x: Float): String =
    (if (x % 1f == 0f) x.toInt().toString() else x.toString()) + "x"

private val PRESETS = listOf(
    "Flat" to intArrayOf(0, 0, 0, 0, 0),
    "Bass" to intArrayOf(7, 4, 0, 0, 0),
    "Vocal" to intArrayOf(-2, 0, 4, 3, 0),
    "Treble" to intArrayOf(0, 0, 0, 4, 7),
    "Rock" to intArrayOf(5, 2, -1, 2, 5),
    "Pop" to intArrayOf(-1, 3, 4, 2, -1)
)

// ───────────────────────── The screen ─────────────────────────

@Composable
fun PlayerScreen(activity: MainActivity) {
    val player = Holder.player
    val ctx = LocalContext.current
    val view = LocalView.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    var ui by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    var showList by remember { mutableStateOf(false) }
    var modal by remember { mutableIntStateOf(0) } // 1 سرعة، 2 إكوالايزر

    var playing by remember { mutableStateOf(player.isPlaying) }
    var title by remember {
        mutableStateOf(player.currentMediaItem?.mediaMetadata?.title?.toString() ?: "")
    }
    var idx by remember { mutableIntStateOf(player.currentMediaItemIndex) }
    var isAudio by remember { mutableStateOf(player.currentMediaItem?.mediaId?.startsWith("a") == true) }
    var hasText by remember { mutableStateOf(false) }
    var cc by remember { mutableStateOf(true) }
    var speed by remember { mutableFloatStateOf(player.playbackParameters.speed) }
    var fit by remember { mutableIntStateOf(0) }
    var mirror by remember { mutableStateOf(false) }
    var night by remember { mutableStateOf(false) }
    var hd by remember { mutableStateOf(false) }
    var muted by remember { mutableStateOf(player.volume == 0f) }
    var rep by remember { mutableIntStateOf(0) }
    var orient by remember { mutableIntStateOf(0) }
    var abA by remember { mutableStateOf<Long?>(null) }
    var abB by remember { mutableStateOf<Long?>(null) }
    var errTick by remember { mutableIntStateOf(0) }
    var osdMsg by remember { mutableStateOf<Pair<Int, String>?>(null) }

    val pos = remember { mutableLongStateOf(0L) }
    val dur = remember { mutableLongStateOf(0L) }

    fun osd(t: String) {
        osdMsg = ((osdMsg?.first ?: 0) + 1) to t
    }

    fun seekBy(delta: Long) {
        val d = player.duration
        val t = player.currentPosition + delta
        player.seekTo(if (d != C.TIME_UNSET) t.coerceIn(0L, d) else t.coerceAtLeast(0L))
    }

    fun curBright(): Float {
        val b = activity.window.attributes.screenBrightness
        return if (b < 0f) 0.5f else b
    }

    fun setBright(v: Float) {
        val lp = activity.window.attributes
        lp.screenBrightness = v
        activity.window.attributes = lp
    }

    // ── مستمع المشغّل ──
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                title = mediaItem?.mediaMetadata?.title?.toString() ?: ""
                idx = player.currentMediaItemIndex
                isAudio = mediaItem?.mediaId?.startsWith("a") == true
                abA = null
                abB = null
            }

            override fun onTracksChanged(tracks: Tracks) {
                hasText = tracks.containsType(C.TRACK_TYPE_TEXT)
            }

            override fun onPlayerError(error: PlaybackException) {
                osd("Cannot play this file")
                errTick++
            }
        }
        player.addListener(l)
        idx = player.currentMediaItemIndex
        onDispose { player.removeListener(l) }
    }

    LaunchedEffect(errTick) {
        if (errTick > 0) {
            delay(900)
            if (player.hasNextMediaItem()) {
                player.seekToNextMediaItem()
                player.prepare()
                player.play()
            }
        }
    }

    // ── تحديث الموضع + حلقة A-B + حفظ التقدّم ──
    LaunchedEffect(Unit) {
        var n = 0
        while (true) {
            val p = player.currentPosition
            pos.longValue = p
            val d = player.duration
            dur.longValue = if (d == C.TIME_UNSET || d < 0) 0L else d
            val a = abA
            val b = abB
            if (a != null && b != null && p >= b) player.seekTo(a)
            n++
            if (n % 24 == 0) Holder.saveNow()
            delay(150)
        }
    }

    LaunchedEffect(Unit) { Fx.attach(player.audioSessionId) }

    // ── إخفاء الأزرار تلقائياً ──
    LaunchedEffect(ui, playing, tick, modal, showList) {
        if (ui && playing && modal == 0 && !showList) {
            delay(3500)
            ui = false
        }
    }
    LaunchedEffect(osdMsg) {
        if (osdMsg != null) {
            delay(1100)
            osdMsg = null
        }
    }

    // ── ملء الشاشة + عدم إطفاء الشاشة ──
    DisposableEffect(Unit) {
        val w = activity.window
        val ctl = WindowCompat.getInsetsController(w, view)
        ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctl.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            ctl.show(WindowInsetsCompat.Type.systemBars())
            val lp = w.attributes
            lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            w.attributes = lp
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
    DisposableEffect(playing) {
        val w = activity.window
        if (playing) w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    // ── الترجمة ──
    val subPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val cur = player.currentMediaItem
        if (uri != null && cur != null) {
            val name = activity.displayName(uri) ?: uri.lastPathSegment ?: "sub.srt"
            val mime = when {
                name.endsWith(".vtt", true) -> MimeTypes.TEXT_VTT
                name.endsWith(".ass", true) || name.endsWith(".ssa", true) -> MimeTypes.TEXT_SSA
                else -> MimeTypes.APPLICATION_SUBRIP
            }
            val sub = MediaItem.SubtitleConfiguration.Builder(uri)
                .setMimeType(mime)
                .setLanguage("und")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            val p = player.currentPosition
            val i = player.currentMediaItemIndex
            player.replaceMediaItem(i, cur.buildUpon().setSubtitleConfigurations(listOf(sub)).build())
            player.seekTo(i, p)
            cc = true
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
            osd("Subtitles loaded")
        }
    }

    fun ccClick() {
        if (!hasText) {
            subPicker.launch(arrayOf("*/*"))
            return
        }
        cc = !cc
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !cc).build()
        osd("Subtitles " + if (cc) "on" else "off")
    }

    fun cycleRep() {
        rep = (rep + 1) % 4
        player.repeatMode = when (rep) {
            2 -> Player.REPEAT_MODE_ONE
            1, 3 -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
        player.shuffleModeEnabled = rep == 3
        osd(listOf("Play once", "Repeat all", "Repeat one", "Shuffle")[rep])
    }

    fun abClick() {
        val a = abA
        val b = abB
        if (a == null) {
            abA = player.currentPosition
            osd("A set")
        } else if (b == null) {
            val now = player.currentPosition
            if (now > a) {
                abB = now
                osd("Looping A-B")
            } else {
                abA = null
            }
        } else {
            abA = null
            abB = null
            osd("A-B off")
        }
    }

    fun rotate() {
        orient = (orient + 1) % 3
        activity.requestedOrientation = when (orient) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        osd(listOf("Auto rotate", "Portrait", "Landscape")[orient])
    }

    fun prev() {
        if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() else player.seekTo(0L)
    }

    fun next() {
        if (player.hasNextMediaItem()) player.seekToNextMediaItem()
    }

    BackHandler {
        when {
            modal != 0 -> modal = 0
            showList -> showList = false
            locked -> osd("Controls locked")
            else -> Holder.closePlayer()
        }
    }

    val paint = remember(night, hd) { fxPaint(night, hd) }
    val fitLabels = listOf("Fit", "Fill", "Stretch")

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // ── الفيديو / غلاف الصوت ──
        if (!isAudio) {
            AndroidView(
                factory = { c ->
                    (LayoutInflater.from(c).inflate(R.layout.player_view, null) as PlayerView).also {
                        it.player = player
                    }
                },
                modifier = Modifier.fillMaxSize(),
                update = { pv ->
                    pv.resizeMode = when (fit) {
                        1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                        else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                    val vs = pv.videoSurfaceView
                    if (vs != null) {
                        vs.scaleX = if (mirror) -1f else 1f
                        vs.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
                    }
                },
                onRelease = { it.player = null }
            )
        } else {
            AudioArt(Vm.queue.getOrNull(idx), title)
        }

        // ── طبقة الإيماءات ──
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(locked) {
                    if (!locked) {
                        detectTapGestures(
                            onTap = {
                                ui = !ui
                                tick++
                            },
                            onDoubleTap = { o ->
                                val right = o.x > size.width / 2f
                                seekBy(if (right) 10000L else -10000L)
                                osd(if (right) "+10s" else "−10s")
                            }
                        )
                    }
                }
                .pointerInput(locked) {
                    if (!locked) {
                        var mode = 0
                        var acc = 0f
                        var b0 = 0.5f
                        var v0 = 0
                        detectVerticalDragGestures(
                            onDragStart = { o ->
                                mode = if (o.x < size.width / 2f) 1 else 2
                                acc = 0f
                                b0 = curBright()
                                v0 = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                            },
                            onDragEnd = {},
                            onDragCancel = {},
                            onVerticalDrag = { change, dy ->
                                change.consume()
                                acc -= dy
                                val f = acc / (size.height * 0.7f)
                                if (mode == 1) {
                                    val nb = (b0 + f).coerceIn(0.02f, 1f)
                                    setBright(nb)
                                    osd("Brightness " + (nb * 100).roundToInt() + "%")
                                } else {
                                    val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                                    val nv = (v0 + f * mx).roundToInt().coerceIn(0, mx)
                                    am.setStreamVolume(AudioManager.STREAM_MUSIC, nv, 0)
                                    osd("Volume " + (nv * 100 / mx) + "%")
                                }
                            }
                        )
                    }
                }
        )

        if (!Vm.inPip) {
            // ── الأزرار ──
            AnimatedVisibility(visible = ui && !locked, enter = fadeIn(), exit = fadeOut()) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .displayCutoutPadding()
                        .padding(8.dp)
                ) {
                    Column(
                        Modifier.align(Alignment.TopCenter),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // الرأس
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .glass()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            IconOrb(Icons.Rounded.ArrowBack) { Holder.closePlayer() }
                            Text(
                                title,
                                modifier = Modifier.weight(1f),
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (!isAudio) {
                                Orb(on = hd, onClick = {
                                    hd = !hd
                                    osd("HD enhance " + if (hd) "on" else "off")
                                }) {
                                    Text("HD", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                            IconOrb(Icons.Rounded.Subtitles, on = cc && hasText) { ccClick() }
                            IconOrb(Icons.Rounded.Tune, on = showTools) { showTools = !showTools }
                            IconOrb(Icons.Rounded.QueueMusic) { showList = !showList }
                        }

                        // الأدوات
                        if (showTools) {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .glass()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                ToolBtn("Night Mode", Icons.Rounded.NightsStay, night) {
                                    night = !night
                                    osd("Night mode " + if (night) "on" else "off")
                                }
                                ToolBtn(
                                    when {
                                        abA == null -> "AB Repeat"
                                        abB == null -> "A → ?"
                                        else -> "A ↔ B"
                                    },
                                    Icons.Rounded.SwapHoriz,
                                    abA != null
                                ) { abClick() }
                                ToolBtn("Pop-up Play", Icons.Rounded.PictureInPictureAlt, false) {
                                    activity.enterPip()
                                }
                                ToolBtn("Equalizer", Icons.Rounded.Equalizer, false) { modal = 2 }
                                ToolBtn("Mirror", Icons.Rounded.Flip, mirror) {
                                    mirror = !mirror
                                    osd("Mirror " + if (mirror) "on" else "off")
                                }
                                ToolBtn(
                                    listOf("Rotation", "Portrait", "Landscape")[orient],
                                    Icons.Rounded.ScreenRotation,
                                    orient != 0
                                ) { rotate() }
                                ToolBtn(
                                    if (muted) "Unmute" else "Mute",
                                    if (muted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                                    muted
                                ) {
                                    muted = !muted
                                    player.volume = if (muted) 0f else 1f
                                }
                                ToolBtn("Background Play", Icons.Rounded.Headset, Vm.bgPlay) {
                                    Vm.bgPlay = !Vm.bgPlay
                                    osd("Background play " + if (Vm.bgPlay) "on" else "off")
                                }
                                ToolBtn(spLabel(speed), Icons.Rounded.Speed, speed != 1f) { modal = 1 }
                                ToolBtn(fitLabels[fit], Icons.Rounded.AspectRatio, false) {
                                    fit = (fit + 1) % 3
                                    osd(fitLabels[fit])
                                }
                                ToolBtn("Lock", Icons.Rounded.Lock, false) {
                                    locked = true
                                    osd("Controls locked")
                                }
                            }
                        }
                    }

                    // الأسفل
                    Column(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .glass()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        SeekRow(pos, dur) { tick++ }
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconOrb(
                                when (rep) {
                                    2 -> Icons.Rounded.RepeatOne
                                    3 -> Icons.Rounded.Shuffle
                                    else -> Icons.Rounded.Repeat
                                },
                                on = rep > 0
                            ) { cycleRep() }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                IconOrb(Icons.Rounded.SkipPrevious) { prev() }
                                IconOrb(
                                    if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    size = 66.dp
                                ) { Holder.toggle() }
                                IconOrb(Icons.Rounded.SkipNext) { next() }
                            }
                            IconOrb(Icons.Rounded.AspectRatio) {
                                fit = (fit + 1) % 3
                                osd(fitLabels[fit])
                            }
                        }
                    }
                }
            }

            // ── زر فك القفل ──
            if (locked) {
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .displayCutoutPadding()
                        .padding(14.dp)
                ) {
                    IconOrb(Icons.Rounded.LockOpen, on = true) {
                        locked = false
                        osd("Unlocked")
                    }
                }
            }

            // ── OSD ──
            osdMsg?.let { m ->
                Text(
                    m.second,
                    color = Color.White,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .displayCutoutPadding()
                        .padding(top = 18.dp)
                        .glass(20.dp)
                        .padding(horizontal = 16.dp, vertical = 7.dp)
                )
            }

            // ── قائمة التشغيل ──
            AnimatedVisibility(
                visible = showList,
                modifier = Modifier.align(Alignment.CenterEnd),
                enter = slideInHorizontally { it },
                exit = slideOutHorizontally { it }
            ) {
                Column(
                    Modifier
                        .displayCutoutPadding()
                        .padding(8.dp)
                        .fillMaxHeight()
                        .width(320.dp)
                        .glassCard()
                ) {
                    Row(
                        Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Playlist (${Vm.queue.size})",
                            modifier = Modifier.weight(1f),
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                        Pill("Clear") {
                            player.stop()
                            player.clearMediaItems()
                            Vm.queue = emptyList()
                            showList = false
                            Vm.showPlayer = false
                        }
                        Pill("Close") { showList = false }
                    }
                    LazyColumn(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                        itemsIndexed(Vm.queue) { i, m ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (i == idx) Color.White.copy(alpha = .25f) else Color.Transparent
                                    )
                                    .clickable {
                                        player.seekTo(i, 0L)
                                        player.play()
                                        showList = false
                                    }
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    if (m.isAudio) Icons.Rounded.MusicNote else Icons.Rounded.PlayArrow,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    m.name,
                                    modifier = Modifier.weight(1f),
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // ── النوافذ ──
    if (modal == 1) {
        Dialog(
            onDismissRequest = { modal = 0 },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Column(
                Modifier
                    .fillMaxWidth(0.92f)
                    .widthIn(max = 380.dp)
                    .glassCard()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Playback speed", color = Color.White, fontWeight = FontWeight.SemiBold)
                listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f).chunked(3).forEach { row ->
                    Row {
                        row.forEach { x ->
                            Pill(spLabel(x), on = speed == x) {
                                speed = x
                                player.setPlaybackSpeed(x)
                            }
                        }
                    }
                }
                Slider(
                    value = speed,
                    onValueChange = {
                        speed = (it * 20).roundToInt() / 20f
                        player.setPlaybackSpeed(speed)
                    },
                    valueRange = 0.25f..4f,
                    colors = sliderColors()
                )
            }
        }
    }
    if (modal == 2) {
        EqDialog { modal = 0 }
    }
}

// ───────────────────────── Pieces ─────────────────────────

@Composable
private fun sliderColors() = SliderDefaults.colors(
    thumbColor = Color.White,
    activeTrackColor = Color(0xFF27C3FF),
    inactiveTrackColor = Color(0x8000225A)
)

@Composable
private fun ToolBtn(label: String, icon: ImageVector, on: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.width(66.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        IconOrb(icon, on = on, onClick = onClick)
        Text(
            label,
            color = Color.White,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun SeekRow(pos: State<Long>, dur: State<Long>, onPoke: () -> Unit) {
    val player = Holder.player
    var drag by remember { mutableStateOf<Float?>(null) }
    val d = dur.value
    val frac = if (d > 0) (pos.value.toFloat() / d).coerceIn(0f, 1f) else 0f
    val dr = drag
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            fmt(if (dr != null) (dr * d).toLong() else pos.value),
            color = Color.White,
            fontSize = 12.sp
        )
        Slider(
            value = dr ?: frac,
            onValueChange = {
                if (drag == null) onPoke()
                drag = it
            },
            onValueChangeFinished = {
                drag?.let { player.seekTo((it * d).toLong()) }
                drag = null
            },
            modifier = Modifier.weight(1f),
            colors = sliderColors()
        )
        Text(fmt(d), color = Color.White, fontSize = 12.sp)
    }
}

@Composable
private fun AudioArt(m: Media?, title: String) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.radialGradient(listOf(Color(0xFF5FC4FF), Color(0xFF0A3D82)))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                Modifier
                    .size(160.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0x33000000)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.MusicNote,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = .8f),
                    modifier = Modifier.size(72.dp)
                )
                if (m != null) Thumb(m, Modifier.fillMaxSize())
            }
            Text(
                title,
                color = Color.White,
                fontSize = 18.sp,
                maxLines = 2,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
        }
    }
}

@Composable
private fun EqDialog(onClose: () -> Unit) {
    val player = Holder.player
    LaunchedEffect(Unit) { Fx.attach(player.audioSessionId) }
    val lv = remember { mutableStateListOf(*Fx.levels.toTypedArray()) }
    var boost by remember { mutableFloatStateOf(Fx.boost) }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            Modifier
                .fillMaxWidth(0.92f)
                .widthIn(max = 380.dp)
                .heightIn(max = 520.dp)
                .glassCard()
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Equalizer", color = Color.White, fontWeight = FontWeight.SemiBold)
            PRESETS.chunked(3).forEach { row ->
                Row {
                    row.forEach { (name, arr) ->
                        Pill(name) {
                            for (i in 0 until 5) {
                                lv[i] = arr[i]
                                Fx.levels[i] = arr[i]
                            }
                            Fx.apply()
                        }
                    }
                }
            }
            for (i in 0 until 5) {
                val f = Fx.FREQ[i]
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        if (f < 1000) "$f Hz" else "${f / 1000} kHz",
                        color = Color.White,
                        fontSize = 12.sp,
                        modifier = Modifier.width(58.dp)
                    )
                    Slider(
                        value = lv[i].toFloat(),
                        onValueChange = {
                            val v = it.roundToInt()
                            lv[i] = v
                            Fx.levels[i] = v
                            Fx.apply()
                        },
                        valueRange = -12f..12f,
                        modifier = Modifier.weight(1f),
                        colors = sliderColors()
                    )
                    Text(
                        "${lv[i]}",
                        color = Color.White,
                        fontSize = 12.sp,
                        modifier = Modifier.width(28.dp)
                    )
                }
            }
            Text("Volume boost", color = Color.White)
            Slider(
                value = boost,
                onValueChange = {
                    boost = it
                    Fx.boost = it
                    Fx.apply()
                },
                valueRange = 1f..3f,
                colors = sliderColors()
            )
        }
    }
}
