package com.aero.player

import android.app.Application
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlin.math.abs
import kotlin.math.ln

// ───────────────────────── Model ─────────────────────────

data class Media(
    val id: Long,
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val size: Long,
    val dateAdded: Long,
    val isAudio: Boolean
) {
    val key: String get() = (if (isAudio) "a" else "v") + id
    val title: String get() = name.substringBeforeLast('.')

    fun toItem(): MediaItem = MediaItem.Builder()
        .setUri(uri)
        .setMediaId(key)
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(title).setArtist("Aero Player").build()
        )
        .build()
}

// ───────────────────────── Saved positions ─────────────────────────

object Store {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) {
        sp = c.getSharedPreferences("aero", Context.MODE_PRIVATE)
    }

    fun pos(key: String): Long = sp.getLong("p:$key", 0L)
    fun setPos(key: String, v: Long) {
        sp.edit().putLong("p:$key", v).apply()
    }
}

// ───────────────────────── Library scan (MediaStore) ─────────────────────────

object MediaRepo {
    fun load(ctx: Context): List<Media> =
        query(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, false) +
            query(ctx, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true)

    private fun query(ctx: Context, base: Uri, audio: Boolean): List<Media> {
        val out = ArrayList<Media>()
        val proj = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.DURATION,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED
        )
        // الصوتيات أقصر من 30 ثانية (نغمات) تُتجاهل
        val sel = if (audio) "${MediaStore.MediaColumns.DURATION} >= 30000" else null
        try {
            ctx.contentResolver.query(
                base, proj, sel, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iDur = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION)
                val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iDate = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    out.add(
                        Media(
                            id = id,
                            uri = ContentUris.withAppendedId(base, id),
                            name = c.getString(iName) ?: "?",
                            durationMs = c.getLong(iDur),
                            size = c.getLong(iSize),
                            dateAdded = c.getLong(iDate),
                            isAudio = audio
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }
}

// ───────────────────────── Shared UI state ─────────────────────────

object Vm {
    var library by mutableStateOf<List<Media>>(emptyList())
    var hasPermission by mutableStateOf(false)
    var loading by mutableStateOf(false)
    var tab by mutableIntStateOf(0) // 0 فيديو، 1 موسيقى، 2 قائمة التشغيل
    var query by mutableStateOf("")
    var sortByName by mutableStateOf(false)
    var queue by mutableStateOf<List<Media>>(emptyList())
    var showPlayer by mutableStateOf(false)
    var inPip by mutableStateOf(false)
    var bgPlay by mutableStateOf(false)
    var resumeTick by mutableIntStateOf(0)
}

// ───────────────────────── The player (one instance for the whole app) ─────────────────────────

object Holder {
    lateinit var player: ExoPlayer

    fun init(ctx: Context) {
        val rf = DefaultRenderersFactory(ctx).setEnableDecoderFallback(true)
        player = ExoPlayer.Builder(ctx, rf)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                // عند الضغط على التالي/السابق أكمل من آخر موضع محفوظ
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK && mediaItem != null) {
                    val p = Store.pos(mediaItem.mediaId)
                    if (p > 2000) player.seekTo(p)
                }
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                Fx.attach(audioSessionId)
            }
        })
    }

    fun playQueue(list: List<Media>, index: Int) {
        if (index !in list.indices) return
        Vm.queue = list
        val m = list[index]
        val saved = Store.pos(m.key)
        val start = if (saved > 2000 && (m.durationMs <= 0L || saved < m.durationMs - 5000)) saved else 0L
        player.setMediaItems(list.map { it.toItem() }, index, start)
        player.prepare()
        player.play()
        Vm.showPlayer = true
    }

    fun toggle() {
        val p = player
        if (p.isPlaying) {
            p.pause()
        } else {
            if (p.playbackState == Player.STATE_ENDED) p.seekTo(p.currentMediaItemIndex, 0L)
            if (p.playbackState == Player.STATE_IDLE) p.prepare()
            p.play()
        }
    }

    fun isVideo(): Boolean = player.currentMediaItem?.mediaId?.startsWith("v") == true

    fun saveNow() {
        val item = player.currentMediaItem ?: return
        val d = player.duration
        if (d == C.TIME_UNSET || d < 10000) return
        val pos = player.currentPosition
        Store.setPos(item.mediaId, if (pos > d - 5000) 0L else pos)
    }

    fun closePlayer() {
        saveNow()
        if (isVideo()) player.pause()
        Vm.showPlayer = false
    }
}

class AeroApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Holder.init(this)
    }
}

// ───────────────────────── Background playback + notification ─────────────────────────

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        session = MediaSession.Builder(this, Holder.player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = Holder.player
        if (!p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.release()
        session = null
        super.onDestroy()
    }
}

// ───────────────────────── Equalizer + volume boost ─────────────────────────

object Fx {
    val FREQ = intArrayOf(60, 230, 910, 3600, 14000)
    val levels = IntArray(5) // dB لكل نطاق
    var boost = 1f           // 1..3

    private var eq: Equalizer? = null
    private var loud: LoudnessEnhancer? = null
    private var sid = -1

    fun attach(sessionId: Int) {
        if (sessionId == 0 || sessionId == sid) return
        release()
        sid = sessionId
        try {
            eq = Equalizer(0, sessionId).also { it.enabled = true }
        } catch (_: Throwable) {
        }
        try {
            loud = LoudnessEnhancer(sessionId).also { it.enabled = true }
        } catch (_: Throwable) {
        }
        apply()
    }

    private fun nearest(hz: Int): Int {
        var best = 0
        var bd = Float.MAX_VALUE
        for (i in FREQ.indices) {
            val d = abs(ln(hz.toFloat().coerceAtLeast(1f)) - ln(FREQ[i].toFloat()))
            if (d < bd) {
                bd = d
                best = i
            }
        }
        return best
    }

    fun apply() {
        try {
            eq?.let { e ->
                val r = e.bandLevelRange
                for (b in 0 until e.numberOfBands.toInt()) {
                    val hz = e.getCenterFreq(b.toShort()) / 1000
                    val ui = nearest(hz)
                    val mb = (levels[ui] * 100).coerceIn(r[0].toInt(), r[1].toInt())
                    e.setBandLevel(b.toShort(), mb.toShort())
                }
            }
            loud?.setTargetGain(((boost - 1f) * 500f).toInt())
        } catch (_: Throwable) {
        }
    }

    fun release() {
        try {
            eq?.release()
        } catch (_: Throwable) {
        }
        try {
            loud?.release()
        } catch (_: Throwable) {
        }
        eq = null
        loud = null
        sid = -1
    }
}
