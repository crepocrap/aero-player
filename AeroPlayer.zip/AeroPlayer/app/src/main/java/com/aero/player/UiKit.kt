package com.aero.player

import android.content.Context
import android.graphics.Bitmap
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar

val AeroBg: Brush = Brush.verticalGradient(
    listOf(Color(0xFF3A9BE8), Color(0xFF0A3D82), Color(0xFF06224F))
)

fun fmt(ms: Long): String {
    if (ms <= 0) return "0:00"
    val t = ms / 1000
    val h = t / 3600
    val m = (t % 3600) / 60
    val s = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun dt(sec: Long): String {
    if (sec <= 0) return ""
    val c = Calendar.getInstance().apply { timeInMillis = sec * 1000 }
    return "${c.get(Calendar.MONTH) + 1}-${c.get(Calendar.DAY_OF_MONTH)}"
}

/** الزجاج الأزرق (Aero glass) */
fun Modifier.glass(radius: Dp = 14.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    return this
        .clip(shape)
        .background(
            Brush.verticalGradient(
                0f to Color.White.copy(alpha = .50f),
                0.5f to Color.White.copy(alpha = .14f),
                0.51f to Color(0x24002864),
                1f to Color.White.copy(alpha = .22f)
            )
        )
        .border(1.dp, Color.White.copy(alpha = .65f), shape)
}

fun Modifier.glassCard(): Modifier {
    val shape = RoundedCornerShape(18.dp)
    return this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(Color(0xF25AB4FA), Color(0xF20A3C82))))
        .border(1.dp, Color.White.copy(alpha = .7f), shape)
}

@Composable
fun Orb(
    on: Boolean = false,
    size: Dp = 46.dp,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    val bg = if (on)
        Brush.verticalGradient(listOf(Color(0xFF8BFFC8), Color(0xFF12A864)))
    else
        Brush.verticalGradient(listOf(Color(0xFF4AA8F0), Color(0xFF0B4F9E)))
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(bg)
            .border(1.dp, Color.White.copy(alpha = .85f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = 2.dp)
                .fillMaxWidth(.78f)
                .fillMaxHeight(.42f)
                .clip(RoundedCornerShape(50))
                .background(
                    Brush.verticalGradient(listOf(Color.White.copy(alpha = .65f), Color.Transparent))
                )
        )
        content()
    }
}

@Composable
fun IconOrb(icon: ImageVector, on: Boolean = false, size: Dp = 46.dp, onClick: () -> Unit) {
    Orb(on = on, size = size, onClick = onClick) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(size * 0.5f))
    }
}

@Composable
fun Pill(text: String, on: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    val bg = if (on)
        Brush.verticalGradient(listOf(Color(0xFFBFFFE0), Color(0xFF2CC886)))
    else
        Brush.verticalGradient(
            0f to Color.White.copy(alpha = .7f),
            0.5f to Color.White.copy(alpha = .1f),
            0.51f to Color(0x40003C8C),
            1f to Color(0x8078D2FF)
        )
    Box(
        Modifier
            .padding(3.dp)
            .clip(shape)
            .background(bg)
            .border(1.dp, Color.White, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

// ───────────────────────── Thumbnails ─────────────────────────

object Thumbs {
    private val cache = LruCache<String, Bitmap>(120)

    fun peek(key: String): Bitmap? = cache.get(key)

    suspend fun get(ctx: Context, m: Media): Bitmap? {
        cache.get(m.key)?.let { return it }
        val b = withContext(Dispatchers.IO) {
            runCatching { ctx.contentResolver.loadThumbnail(m.uri, Size(320, 192), null) }.getOrNull()
        }
        if (b != null) cache.put(m.key, b)
        return b
    }
}

@Composable
fun Thumb(m: Media, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var bmp by remember(m.key) { mutableStateOf(Thumbs.peek(m.key)) }
    LaunchedEffect(m.key) {
        if (bmp == null) bmp = Thumbs.get(ctx, m)
    }
    val b = bmp
    if (b != null) {
        Image(b.asImageBitmap(), contentDescription = null, modifier = modifier, contentScale = ContentScale.Crop)
    }
}

// ───────────────────────── Player state helpers ─────────────────────────

@Composable
fun rememberIsPlaying(): State<Boolean> {
    val s = remember { mutableStateOf(Holder.player.isPlaying) }
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                s.value = isPlaying
            }
        }
        Holder.player.addListener(l)
        onDispose { Holder.player.removeListener(l) }
    }
    return s
}

@Composable
fun rememberTitle(): State<String> {
    val s = remember {
        mutableStateOf(Holder.player.currentMediaItem?.mediaMetadata?.title?.toString() ?: "")
    }
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                s.value = mediaItem?.mediaMetadata?.title?.toString() ?: ""
            }
        }
        Holder.player.addListener(l)
        onDispose { Holder.player.removeListener(l) }
    }
    return s
}
