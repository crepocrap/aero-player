package com.aero.player

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LibraryScreen(onAllow: () -> Unit, onSettings: () -> Unit, onRescan: () -> Unit) {
    var searching by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val playerPlaying by rememberIsPlaying()

    val items = remember(Vm.library, Vm.tab, Vm.query, Vm.sortByName, Vm.queue) {
        val q = Vm.query.trim().lowercase()
        val base = if (Vm.tab == 2) Vm.queue else Vm.library.filter { it.isAudio == (Vm.tab == 1) }
        val f = if (q.isEmpty()) base else base.filter { it.name.lowercase().contains(q) }
        when {
            Vm.tab == 2 -> f
            Vm.sortByName -> f.sortedBy { it.name.lowercase() }
            else -> f.sortedByDescending { it.dateAdded }
        }
    }
    val currentKey = remember(Vm.showPlayer, playerPlaying, Vm.queue) {
        Holder.player.currentMediaItem?.mediaId
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // ── الرأس ──
        Row(
            Modifier
                .fillMaxWidth()
                .glass()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (searching) {
                BasicTextField(
                    value = Vm.query,
                    onValueChange = { Vm.query = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0x80002050))
                        .border(1.dp, Color.White, RoundedCornerShape(20.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                )
            } else {
                Text(
                    "Aero Library",
                    modifier = Modifier.weight(1f),
                    color = Color.White,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Light
                )
            }
            IconOrb(Icons.Rounded.Search) {
                searching = !searching
                if (!searching) Vm.query = ""
            }
            Box {
                IconOrb(Icons.Rounded.MoreVert) { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Rescan") }, onClick = { menu = false; onRescan() })
                    DropdownMenuItem(
                        text = { Text(if (Vm.sortByName) "Sort: by date" else "Sort: by name") },
                        onClick = { menu = false; Vm.sortByName = !Vm.sortByName }
                    )
                }
            }
        }

        // ── المحتوى ──
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when {
                !Vm.hasPermission -> Column(
                    Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Allow Aero Player to see the videos and music on your device.",
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Row(Modifier.padding(top = 12.dp)) {
                        Pill("Allow access", onClick = onAllow)
                        Pill("Open settings", onClick = onSettings)
                    }
                }

                Vm.loading && Vm.library.isEmpty() -> Centered("Scanning…")
                items.isEmpty() -> Centered(
                    if (Vm.tab == 2) "Nothing in the playlist yet." else "No media found."
                )

                Vm.tab == 0 -> LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(2.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(items, key = { _, m -> m.key }) { i, m ->
                        VideoCard(m) { Holder.playQueue(items, i) }
                    }
                }

                else -> LazyColumn(
                    contentPadding = PaddingValues(2.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(items, key = { _, m -> m.key }) { i, m ->
                        MediaRow(m, current = m.key == currentKey) {
                            if (Vm.tab == 2) {
                                Holder.player.seekTo(i, 0L)
                                Holder.player.play()
                                Vm.showPlayer = true
                            } else {
                                Holder.playQueue(items, i)
                            }
                        }
                    }
                }
            }
        }

        // ── مشغّل مصغّر ──
        if (Vm.queue.isNotEmpty()) MiniBar()

        // ── التبويبات ──
        Row(Modifier.fillMaxWidth().glass()) {
            TabBtn("Video", Icons.Rounded.VideoLibrary, Vm.tab == 0, Modifier.weight(1f)) { Vm.tab = 0 }
            TabBtn("Music", Icons.Rounded.LibraryMusic, Vm.tab == 1, Modifier.weight(1f)) { Vm.tab = 1 }
            TabBtn("Playlist", Icons.Rounded.QueueMusic, Vm.tab == 2, Modifier.weight(1f)) { Vm.tab = 2 }
        }
    }
}

@Composable
private fun Centered(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White.copy(alpha = .8f), textAlign = TextAlign.Center)
    }
}

@Composable
private fun TabBtn(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val c = Color.White.copy(alpha = if (selected) 1f else .65f)
        Icon(icon, contentDescription = null, tint = c, modifier = Modifier.size(26.dp))
        Text(label, color = c, fontSize = 12.sp)
    }
}

@Composable
private fun MiniBar() {
    val playing by rememberIsPlaying()
    val title by rememberTitle()
    Row(
        Modifier
            .fillMaxWidth()
            .glass()
            .clickable { Vm.showPlayer = true }
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp),
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        IconOrb(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, size = 40.dp) {
            Holder.toggle()
        }
    }
}

@Composable
private fun VideoCard(m: Media, onClick: () -> Unit) {
    val saved = remember(m.key, Vm.showPlayer) { Store.pos(m.key) }
    val shape = RoundedCornerShape(8.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(5f / 3f)
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFF2A6FB8), Color(0xFF0A3D82))))
                .border(1.dp, Color.White.copy(alpha = .5f), shape)
        ) {
            Icon(
                Icons.Rounded.PlayArrow,
                contentDescription = null,
                tint = Color.White.copy(alpha = .6f),
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(28.dp)
            )
            Thumb(m, Modifier.fillMaxSize())
            if (m.durationMs > 0) {
                Text(
                    fmt(m.durationMs),
                    color = Color.White,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(5.dp)
                        .background(Color(0xB3001E3C), RoundedCornerShape(5.dp))
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                )
                if (saved > 0) {
                    Box(
                        Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth((saved.toFloat() / m.durationMs).coerceIn(0.01f, 1f))
                            .height(3.dp)
                            .background(Color(0xFFFFB400))
                    )
                }
            }
        }
        Text(
            m.name,
            color = Color.White,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 5.dp)
        )
        Text(dt(m.dateAdded), color = Color.White.copy(alpha = .7f), fontSize = 11.sp)
    }
}

@Composable
private fun MediaRow(m: Media, current: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (current) Color.White.copy(alpha = .22f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            Modifier
                .size(width = 84.dp, height = 52.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0x66002864)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (m.isAudio) Icons.Rounded.MusicNote else Icons.Rounded.PlayArrow,
                contentDescription = null,
                tint = Color.White.copy(alpha = .7f),
                modifier = Modifier.size(24.dp)
            )
            Thumb(m, Modifier.fillMaxSize())
        }
        Column(Modifier.weight(1f)) {
            Text(
                m.name,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 14.sp
            )
            Text(
                listOf(fmt(m.durationMs), dt(m.dateAdded)).filter { it.isNotEmpty() }.joinToString(" · "),
                color = Color.White.copy(alpha = .7f),
                fontSize = 11.sp
            )
        }
    }
}
