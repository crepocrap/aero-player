package com.aero.player

import android.Manifest
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var controller: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        // الاتصال بالخدمة يشغّلها ويُظهر إشعار التحكم أثناء التشغيل بالخلفية
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controller = MediaController.Builder(this, token).buildAsync()

        setContent { AeroRoot(this) }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        Vm.resumeTick++
    }

    override fun onStop() {
        super.onStop()
        Holder.saveNow()
        if (!Vm.bgPlay && Holder.isVideo() && !isInPictureInPictureMode) {
            Holder.player.pause()
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Vm.showPlayer && Holder.player.isPlaying && Holder.isVideo()) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        Vm.inPip = isInPictureInPictureMode
    }

    override fun onDestroy() {
        controller?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }

    fun enterPip() {
        val vs = Holder.player.videoSize
        var r = if (vs.width > 0 && vs.height > 0)
            vs.width.toFloat() * vs.pixelWidthHeightRatio / vs.height
        else 16f / 9f
        r = r.coerceIn(0.45f, 2.3f)
        try {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational((r * 1000).toInt(), 1000))
                    .build()
            )
        } catch (_: Exception) {
        }
    }

    fun displayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) {
        null
    }

    private fun handleIntent(i: Intent?) {
        val uri = i?.data ?: return
        if (i.action != Intent.ACTION_VIEW) return
        val name = displayName(uri) ?: uri.lastPathSegment ?: "Video"
        val type = contentResolver.getType(uri) ?: i.type ?: ""
        val m = Media(
            id = uri.toString().hashCode().toLong(),
            uri = uri,
            name = name,
            durationMs = 0L,
            size = 0L,
            dateAdded = 0L,
            isAudio = type.startsWith("audio")
        )
        Holder.playQueue(listOf(m), 0)
    }
}

@Composable
fun AeroRoot(activity: MainActivity) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val need = remember {
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        else
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    fun anyGranted(): Boolean = need.any {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

    fun refresh() {
        if (anyGranted()) {
            Vm.hasPermission = true
            scope.launch {
                Vm.loading = true
                Vm.library = withContext(Dispatchers.IO) { MediaRepo.load(ctx) }
                Vm.loading = false
            }
        } else {
            Vm.hasPermission = false
        }
    }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refresh() }

    fun ask() {
        val all = if (Build.VERSION.SDK_INT >= 33) need + Manifest.permission.POST_NOTIFICATIONS else need
        launcher.launch(all)
    }

    LaunchedEffect(Vm.resumeTick) { refresh() }
    LaunchedEffect(Unit) { if (!anyGranted()) ask() }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(AeroBg)
        ) {
            LibraryScreen(
                onAllow = { ask() },
                onSettings = {
                    ctx.startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", ctx.packageName, null)
                        )
                    )
                },
                onRescan = { refresh() }
            )
            if (Vm.showPlayer) PlayerScreen(activity)
        }
    }
}
